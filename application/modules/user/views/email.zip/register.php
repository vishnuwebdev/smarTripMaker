

 <?php $this->load->view("header"); ?>
<link href="<?php echo site_url(); ?>assets/css/login.css" rel="stylesheet">

<body>

   
    
    <!-- /card-container -->
   <div class="bg">
        <div class="container">
             <?php
        if ($this->session->flashdata('customer_id') !== NULl) {
            $bhanu_message = $this->session->flashdata('customer_id');
            ?>

            <div
                class="alert alert-sm alert-border-left alert-danger  light alert-dismissable">
                <button type="button" class="close" data-dismiss="alert"
                        aria-hidden="true">×</button>
                <i class="fa fa-info pr10"></i> <strong> <?php echo $bhanu_message; ?></strong>
            </div>

        <?php } ?>

            <div class="sm-hidden" style="padding-top: 50px;">
            </div>
                <div class="col-xs-12 col-sm-8 col-md-6 col-sm-offset-2 col-md-offset-6 registration-box" style="margin-bottom: 50px;background: #ffff;">
                   <form role="form" style="padding-bottom: 20px;" action="<?php echo site_url();?>user/registration" method="post" id="register">
                    
                    <?php echo form_error('myfield', '<div class="error">', '</div>');?>
					<?php if(validation_errors()!=NULL){?>	
					<div class="alert alert-big alert-lightred alert-dismissable fade in">
                                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                        <?php echo validation_errors(); ?>
                                    </div>
                                    <?php }?>
                    <h2 style="color: #ed8323;"><?php echo $this->lang->line('please_sign_up'); ?> <small><?php echo $this->lang->line('its_always_free'); ?></small></h2>
                    <hr class="colorgraph">
                    <div class="row">
                        <div class="col-xs-12 col-sm-6 col-md-6">
                            <div class="form-group">
                                <input type="text" name="first_name" id="first_name" class="form-control input-lg" placeholder="<?php echo $this->lang->line('first_name'); ?>" tabindex="1">
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-6 col-md-6">
                            <div class="form-group">
                                <input type="text" name="last_name" id="last_name" class="form-control input-lg" placeholder="<?php echo $this->lang->line('last_name'); ?>" tabindex="2">
                            </div>
                        </div>
                    </div>
					<div class="row">
					<div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <input type="text" name="mobile_no" id="display_name" class="form-control input-lg" placeholder="<?php echo $this->lang->line('mobile_no'); ?>" tabindex="3">
                    </div>
					</div>
					</div>
					<div class="row">
					<div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <input type="email" name="email_address" id="email" class="form-control input-lg" placeholder="<?php echo $this->lang->line('email_address_title'); ?>" tabindex="4">
                    </div>
					</div>
					</div>
                    <div class="row">
                        <div class="col-xs-12 col-sm-6 col-md-6">
                            <div class="form-group">
                                <input type="password" name="password" id="password" class="form-control input-lg" placeholder="<?php echo $this->lang->line('password_title'); ?>" tabindex="5">
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-6 col-md-6">
                            <div class="form-group">
                                <input type="password" name="password_confirmation" id="password_confirmation" class="form-control input-lg" placeholder="<?php echo $this->lang->line('confirm_password'); ?>" tabindex="6">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-4 col-sm-3 col-md-3">
                            <span class="button-checkbox">
                                <button type="button" class="btn" data-color="info" tabindex="7">
                                    <div class="checkbox t_and_c" style="margin: 0;">
                                        <label><input type="checkbox" value="">I Agree</label>
                                    </div></button>
                                <input type="checkbox" name="t_and_c" id="t_and_c" class="hidden" value="1">
                            </span>
                        </div>
                        <div class="col-xs-8 col-sm-9 col-md-9">
                            <?php echo $this->lang->line('by_click_register'); ?>
                        </div>
                    </div>

                    <hr class="colorgraph">
                    <div class="row">
                        <div class="col-xs-6 col-md-6"><input type="submit" value="<?php echo $this->lang->line('register'); ?>" class="btn btn-primary btn-block btn-lg" tabindex="7"></div>
                        <div class="col-xs-6 col-md-6"><a href="<?php echo site_url(); ?>user/login" class="btn btn-success btn-block btn-lg"><?php echo $this->lang->line('login_title'); ?></a></div>
                    </div>
                </form>
                </div>
        </div>
    </div>
    <!-- /container -->


    <?php $this->load->view("footer"); ?>
    <?php $this->load->view("js"); ?>

   
</body>

