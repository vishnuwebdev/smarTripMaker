

 <?php $this->load->view("header"); ?>
<style>
.box_div{
    background: #ffffff9c;
    padding: 35px;
    margin-bottom: 20px;
    border-radius: 12px;
}
.body_backgorund{
	background-size:100% 100%;
}
</style>
<link href="<?php echo site_url(); ?>assets/css/login.css" rel="stylesheet">

<body>

   
    <div class="container mb-40 min-height-460" style="padding-top: 40px;">

    <div class="row">
        <div class="col-md-6 col-md-offset-3 box_div">

    <?php
      if ($this->session->flashdata('alert_forgot') !== NULl) {
          $bhanu_message = $this->session->flashdata('alert_forgot');
          ?>

          <div
              class="alert alert-sm alert-border-left <?php echo $bhanu_message['class']; ?>  light alert-dismissable">
              <button type="button" class="close" data-dismiss="alert"
                      aria-hidden="true">×</button>
              <i class="fa fa-info pr10"></i> <strong> <?php echo $bhanu_message['message']; ?></strong>
          </div>

      <?php } ?>

        <P>Enter your registered email </p>
        <div class="card card-container">

        
         
            <form class="form-signin" action="<?php echo site_url(); ?>user/forgotpassword" method="post">
                <span id="reauth-email" class="reauth-email"></span>
                <input type="email" id="inputEmail" class="form-control" placeholder="Email address" required autofocus name="email">
               
                
                <button style="margin-top:10px" class="btn btn-primary btn-block" type="submit">Submit</button>
            </form>
            <!-- /form -->
            <p class="pt-15 text-right"><a style="margin-top:10px" href="<?php echo site_url(); ?>user/login" class="forgot-password">
                Sign In.
            </a></p>
        </div>
        <!-- /card-container -->

        </div>
        </div>

    </div>
    <!-- /container -->


    <?php $this->load->view("footer"); ?>


</body>

