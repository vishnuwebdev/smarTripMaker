<?php $this->load->view("commenLayout/head"); ?>
<link href="<?php echo site_url(); ?>assets/css/login.css" rel="stylesheet">
 <style type="text/css">
        .wrapper {
        display: flex;
}

#sidebar {
        min-width: 250px;
        max-width: 250px;
        height: 100vh;
}
.myprofileimg {
    width: 100%;
    display: block;
    border-radius: 50%;
    max-width: 100px;
    margin: 0 auto;
    border: 1px solid #777777;
    box-shadow: 0px 6px 12px #949494;
    padding: 2px;
}

.tac {
    text-align: center;
}
.border-left {
    border-left: 1px solid #dddddd;
}
.table {
    width: 100%;
    max-width: 100%;
    margin-bottom: 20px;
}

.text_cap{
	text-transform: capitalize;
}

.fz18 {
    font-size: 18px;
}
.profiletablegrabber b {
    font-weight: normal;
}
    </style>
<body>

    <?php $this->load->view("commenLayout/header"); ?>

    
   <section id="dashboard">
       <div class="container" style="width: 97%;">
      <div class="wrapper">
     
          <?php $this->load->view("customersidebar"); ?>

        <div class="content col-md-12 bp_shadow" style="width: 100%;background: #fff;">
           
            <div class="" style="padding: 1px 10px;">
                 <h2> Profile</h2> 
             <section id="content">
	<div class="page page-forms-validate">
		<div class="pageheader">
			
		</div>
		<!-- row -->

		<div class="row">
                                    <div class="col-sm-3">
                                     
									<?php if($result->cust_profile_pic !=""){?>
										 <img  class="myprofileimg"  src="<?php echo site_url();?>assets/profile_pic/<?php echo $result->cust_profile_pic; ?>" >
									<?php }else{?>
									 
									        <img src="http://beta.booking-tours.com/assets/holiday/images/propic.jpg" alt="" class="myprofileimg">
									<?php } ?>   
                                        <h3 class="tac fz18 black-color text_cap"><?php echo $result->cust_first_name ." ".$result->cust_last_name  ?></h3>
                                    </div>
                                    <div class="col-sm-9 border-left">
                                     
                                            <h3 style="margin-top:15px" class="fz18 black-color clearfix">Profile Details <!-- <a href="http://beta.booking-tours.com/user/editprofile" class="right">Edit Profile</a> --> </h3>
                                            <div class="profiletablegrabber mb0">
                                                <table class="table table-hover table-bordered mb0">
                                                    <tbody>
                                                        <tr>
                                                            <td class="firsttd"><b>Full Name</b></td>
                                                            <td><b><?php echo $result->cust_first_name ." ".$result->cust_last_name  ?></b></td>
                                                        </tr>
                                                        <tr>
                                                            <td class="firsttd"><b>First Name</b></td>
                                                            <td><b><?php echo $result->cust_first_name ?></b></td>
                                                        </tr>
                                                        <tr>
                                                            <td class="firsttd"><b>Last Name</b></td>
                                                            <td><b><?php echo $result->cust_last_name; ?></b></td>
                                                        </tr>
                                                        <tr>
                                                            <td class="firsttd"><b>Phone Number</b></td>         
                                                            <td><b><?php echo $result->cust_mobile; ?></b></td>
                                                        </tr>
                                                        <tr>
                                                            <td class="firsttd"><b>Email ID</b></td>
                                                            <td><b><?php echo $result->cust_email; ?></b></td>
                                                        </tr>
                                                        <!-- <tr>
                                                            <td class="firsttd"><b>Country</b></td>         
                                                            <td><b></b></td>
                                                        </tr>
                                                        <tr>
                                                            <td class="firsttd"><b>State</b></td>         
                                                            <td><b></b></td>
                                                        </tr>
                                                        <tr>
                                                            <td class="firsttd"><b>City</b></td>         
                                                            <td><b></b></td>
                                                        </tr>
                                                        <tr>
                                                            <td class="firsttd"><b>Address</b></td>         
                                                            <td><b></b></td>
                                                        </tr>
                                                        <tr>
                                                            <td class="firsttd"><b>Zipcode</b></td>         
                                                            <td><b></b></td>
                                                        </tr> -->
                                                    </tbody>
                                                </table>
                                            </div>
                                       
                                    </div>
                                </div>















		<!-- /row -->
	</div>
</section>   
                
            </div>

           
        </div>
    </div>
      </div>
    </section>

<?php $this->load->view("commenLayout/footer"); ?>
<?php $this->load->view("js"); ?>

<script>
$('#upload_profile').click(function(){
	$('#update_data').submit();
})
</script>