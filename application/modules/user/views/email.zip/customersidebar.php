

        <div class="col-md-3 ">
		     <div class="list-group ">
              <a href="<?php echo site_url(); ?>user/dashboard" class="list-group-item list-group-item-action active">Dashboard</a>
              <a href="<?php echo site_url(); ?>user/dashboard" class="list-group-item list-group-item-action">Flight Bookings</a>
              <a href="<?php echo site_url(); ?>user/editprofile" class="list-group-item list-group-item-action">Edit Profile</a>
              
              
            </div> 
		</div> 