<?php $this->load->view("header"); ?>

<body>
<section id="special" class="p-xs-8">
		<div class="container-fluid">
	<div class="row">
	<?php
                    if ($this->session->flashdata('edit_profile') !== NULl) {
                        $bhanu_message = $this->session->flashdata('edit_profile');
                        ?>

                        <div
                            class="alert alert-sm alert-border-left <?php echo $bhanu_message['class']; ?>  light alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert"
                                    aria-hidden="true">×</button>
                            <i class="fa fa-info pr10"></i> <strong> <?php echo $bhanu_message['message']; ?></strong>
                        </div>

     <?php } ?>


            <?php $this->load->view("customersidebar"); ?>

		
		<div class="col-md-9">
		    <div class="card">
		        <div class="card-body" style="background: white;">
		            <div class="row">
		                <div class="col-md-12">
		                    <h4>Edit Profile</h4>
		                    <hr>
		                </div>
		            </div>
		            <div class="row">
		                <div class="col-md-12">
							<?php $attributes = array('class' => 'form-horizontal','id'=>'add_blog_category'); ?>
								<?php echo form_open_multipart('user/editprofile',$attributes); ?>
								<!-- tile body -->
								<div class="tile-body">
								<input type="hidden" name="id" value="<?php echo url_encode($result->cust_id); ?>">
								<?php echo form_error('myfield', '<div class="error">', '</div>');?>
								<?php if(validation_errors()!=NULL){?>	
								<div class="alert alert-big alert-lightred alert-dismissable fade in">
													<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
													<?php echo validation_errors(); ?>
												</div>
												<?php }?>
										<div class="form-group">
											<label class="col-sm-2 control-label">first Name</label>
											<div class="col-sm-9">
												<div class="input text">
														<?php echo form_input(array('name'=>'first_name','class'=>'form-control','placeholder'=>'Category Name'),$result->cust_first_name);?>
														<?php echo form_error('first_name', '<div class="error">', '</div>');?>
												</div>
											</div>
										</div>
										<div class="form-group">
											<label class="col-sm-2 control-label">last name</label>
											<div class="col-sm-9">
												<div class="input text">
													<input type="text" name="last_name"
														placeholder="last name"  class="form-control" value="<?php echo $result->cust_last_name; ?>">
												</div>
											</div>
										</div>
										<div class="form-group">
											<label class="col-sm-2 control-label">Email Id </label>
											<div class="col-sm-9">
												<div class="input text">
													<input type="text" name="tag"
														placeholder="Category tag" class="form-control" readonly value="<?php echo $result->cust_email; ?>">
												</div>
											</div>
										</div>
													<div class="form-group">
											<label class="col-sm-2 control-label">Mobile No</label>
											<div class="col-sm-9">
												<div class="input text">
													<input type="text" name="cust_mobile"
														placeholder="Mobile Number" class="form-control" value="<?php echo $result->cust_mobile; ?>">
												</div>
											</div>
										</div>
									<!--	<div class="form-group">
											<label class="col-sm-2 control-label">profile Image</label>
											<div class="col-sm-9">
												<div class="input text">
													<input class="form-control" type="file" name="userfile" />
												</div>
											</div>
											 <div class="col-sm-9 col-md-offset-2">
																	<?php if($result->cust_profile_pic !=""){?>
																	<img src="<?php echo site_url();?>assets/img/blog/<?php echo $result->cust_profile_pic; ?>" class="img-responsive thumbnail mr25" style="width: 100%;">
																	<?php }else{?>
																	<div class="alert alert-sm alert-border-left alert-danger light alert-dismissable bp_incomplete_info_alert">
										image not uploaded ,Please select a image and upload
										</div>
																	<?php }?>
																</div> 
										</div> -->
										
										
											
											
											
								</div>
								<!-- /tile body -->
								<!-- tile footer -->
								<div class="tile-footer text-center bg-tr-black lter dvd dvd-top">
									<!-- SUBMIT BUTTON -->
											<div class="submit">
												<input type="submit" class="btn btn-success" value="Submit">
											</div>
								</div>
								<!-- /tile footer -->
								</form>
		                </div>
		            </div>
		            
		        </div>
		    </div>
		</div>
	</div>
</div>

    


<?php $this->load->view("footer"); ?>

				
			