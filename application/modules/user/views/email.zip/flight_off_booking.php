<?php $this->load->view("commenLayout/head"); ?>
<link href="<?php echo site_url(); ?>assets/css/login.css" rel="stylesheet">
 <style type="text/css">
        .wrapper {
        display: flex;
}

#sidebar {
        min-width: 250px;
        max-width: 250px;
        height: 100vh;
}
    </style>
<body>

    <?php $this->load->view("commenLayout/header"); ?>

    
   <section id="dashboard">
       <div class="container" style="width:97%">
      <div class="wrapper">
    
          <?php $this->load->view("customersidebar"); ?>

          <div id="content" class="dashbord-content" style="width: 100%">
            <h2>Flight Special Bookings</h2>
           

            <div class="tab-content">
              <div id="home" class="tab-pane fade in active">
              <table class="table table-striped custab table-bordered mt20 table-font-14">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Pax</th>
                                                <th>Amount</th>
                                                <th>Segment</th>
                                                <th>Date</th>
                                                <th>Status </th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        
<?php 
if(count($FBookingList) > 0){
	$i=1;
foreach ($FBookingList as $Listing) { ?>
                                            <tr>
                                                <td><?php echo $Listing['booklist']->fliofbook_id; ?></td>
                                                <td><?php foreach ($Listing["paxlist"] as $paxlist) { ?>
                                                        <b> <?php echo $paxlist->flofpax_title . '. ' . $paxlist->flofpax_first_name . ' ' . $paxlist->flofpax_last_name; ?><br> </b>


    <?php } ?></td>
                                                <td>Rs. <?php echo $Listing['booklist']->fliofbook_customer_fare; ?></td>
                                                <td><b>From: </b><?php echo $Listing['booklist']->fliofbook_depart_city . ', ' . $Listing['booklist']->fliofbook_depart_airport_code; ?><br>
                                                    <b>To: </b> <?php echo $Listing['booklist']->fliofbook_arrive_city . ', ' . $Listing['booklist']->fliofbook_arrive_airport_code; ?><br> 
                                                    <!-- <b>B Type: </b><?php echo $Listing['booklist']->fliofbook_booking_type; ?> <br> -->
                                                </td>
                                                <td>
                                                    <b> B Date:</b> <?php echo date_format(date_create($Listing['booklist']->fliofbook_entry_date),"h:i A , d M Y") ?>
                                                    <br><b>D. Date: </b><?php echo $Listing['booklist']->fliofbook_depart_date; ?>
                                                    <br>
                                                    <?php
                                                    if (!empty($Listing['booklist']->fliofbook_return_date)) {
                                                        echo '<b>R. Date: </b>' . $Listing['booklist']->fliofbook_return_date;
                                                    }
                                                    ?>
                                                   
                                                </td>


                                                <td> 
                                                     <b>Booking Status: </b><?php echo $Listing['booklist']->fliofbook_booking_status; ?><br>
                                                   
                                                    </td>



                                                <td class="text-center">
                                                   
                                                    
                                                    <a target="_blank" class="btn btn-info btn-Sd btn-xs" href="<?php echo site_url(); ?>flight/print_ticket_spc?ref_id=<?php echo url_encode($Listing['booklist']->fliofbook_id); ?>"><span class="glyphicon glyphicon-edit"></span> Print Ticket</a> <br><br>
                                                    <a target="_blank" class="btn btn-primary btn-Sd btn-xs" href="<?php echo site_url(); ?>flight/print_invoice_spc?ref_id=<?php echo url_encode($Listing['booklist']->fliofbook_id); ?>"><span class="fa fa-print"></span> Print Invoice</a> <br><br>
                                                    <!-- <a href="<?php echo site_url(); ?>flight/cancel_request?ref_id=<?php echo url_encode($Listing['booklist']->fbook_id); ?>" class="btn btn-warning btn-Sd btn-xs"><span class="glyphicon glyphicon-remove"></span>Cancel Flight</a> -->
                                                   
                                                </td>
                                            </tr>
 <?php $i++; } } else{ ?>
                          
                       <tr>
                           <td colspan="8">not found any record.</td>   
                  <?php } ?>
                                    </table>
              </div>
              
              
              
            </div>
        </div>
    </div>
      </div>
    </section>

<?php $this->load->view("commenLayout/footer"); ?>


    <?php $this->load->view("js"); ?>