<?php $this->load->view('header') ?>

<link href="<?php echo site_url(); ?>assets/css/login/login.css" rel="stylesheet" media="screen">

    <style>
      .keeplogin label {
            width: 40%;
        }
        .navbar-contact a {
    color: #f7f7f7;
    display: inline-block;
}
.transparent-menu{
    background:white;

}
.text-align-center{
    text-align:center;
}
.body_backgorund {
    background-size: 100% 75%;
    background-repeat: no-repeat;
        font-family: 'Open Sans', sans-serif;
    text-rendering: optimizeLegibility;
    -webkit-font-smoothing: antialiased;
}
.error{
	color:red;
}
    </style>

<div class="container1">

           <!-- <header>
            <a href="<?php echo site_url();?>"><img src="<?php echo site_url() ?>assets/images/logo.png"></a>
           </header> -->
           <section>				
               <div id="container_demo" >
                
                <?php
                    if ($this->session->flashdata('alert_register') !== NULl) {
                        $bhanu_message = $this->session->flashdata('alert_register');
                        ?>
                          
                        <div
                            class="alert alert-sm alert-border-left <?php echo $bhanu_message['class']; ?>  light alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert"
                                    aria-hidden="true">×</button>
                            <i class="fa fa-info pr10"></i> <strong> <?php echo $bhanu_message['message']; ?></strong>
                        </div>

                    <?php } ?>

                        <?php
                    if ($this->session->flashdata('alert_login') !== NULl) {
                        $bhanu_message = $this->session->flashdata('alert_login');
                        ?>

                        <div
                            class="alert alert-sm alert-border-left <?php echo $bhanu_message['class']; ?>  light alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert"
                                    aria-hidden="true">×</button>
                            <i class="fa fa-info pr10"></i> <strong> <?php echo $bhanu_message['message']; ?></strong>
                        </div>

            <?php } ?>
			
			<!--Forgot-->
            <?php
			  if ($this->session->flashdata('alert_forgot') !== NULl) {
				  $bhanu_message = $this->session->flashdata('alert_forgot');
				  ?>

				  <div
					  class="alert alert-sm alert-border-left <?php echo $bhanu_message['class']; ?>  light alert-dismissable">
					  <button type="button" class="close" data-dismiss="alert"
							  aria-hidden="true">×</button>
					  <i class="fa fa-info pr10"></i> <strong> <?php echo $bhanu_message['message']; ?></strong>
				  </div>

			  <?php } ?>


                   <!-- hidden anchor to stop jump http://www.css3create.com/Astuce-Empecher-le-scroll-avec-l-utilisation-de-target#wrap4  -->
                   <a class="hiddenanchor" id="toregister"></a>
                   <a class="hiddenanchor" id="tologin"></a>
                   <a class="hiddenanchor" id="tootp"></a>
				   <a class="hiddenanchor" id="toforgot"></a>
                   <div id="wrapper">
                       <div id="login" class="animate form">
                            <form class="form-signin" action="<?php echo site_url(); ?>user/login" method="post">
                               <h1>Log in</h1> 
                               <p> 
                                   <label for="username" class="uname" > Your email or username </label>
                                   <input id="username" autofocus name="email" required="required" type="text" placeholder="myusername or mymail@mail.com"/>
                               </p>
                               <p> 
                                   <label for="password" class="youpasswd"> Your password </label>
                                   <input id="password" name="password" required="required" type="password" placeholder="eg. X8df!90EO" /> 
                               </p>
                               <p class="keeplogin"> 
                                   
                                   <label style="float:right;margin-top: 5px; text-align:right;"><a style="text-decoration:none;color: rgb(64, 92, 96);" href="#toforgot">Forgot Password </a></label>
                               </p>
                               <p class="login button"> 
                                  <input type="submit" value="Log In">
                               </p>
                               <p class="change_link">
                                   Not a member yet ?
                                   <a href="#toregister" class="singup_btn to_register">Join us</a>
                               </p>
                           </form>
                       </div>

                       <div id="register" class="animate form">
                       <form id="register_singup" role="form" style="padding-bottom: 0px;" action="<?php echo site_url();?>user/registration" method="post" id="register1">
                               <h1> Sign up </h1> 
                               <p> 
                                   <label for="a"   class="uname" >First Name</label>
                                   <input id="c" onkeypress="return (event.charCode > 64 && 
event.charCode < 91) || (event.charCode > 96 && event.charCode < 123) " name="first_name" required="required" type="text" placeholder="First Name" />
                               </p>
                               <p> 
                                   <label for="a"   class="uname" >Last Name</label>
                                   <input id="d" onkeypress="return (event.charCode > 64 && 
event.charCode < 91) || (event.charCode > 96 && event.charCode < 123) " name="last_name" required="required" type="text" placeholder="Last Name" />
                               </p>
                               <p> 
                                   <label for="c" class="uname" >Mobile Number</label>
                                   <input id="a" name="mobile_no" required="required" type="Number" placeholder="Mobile Number" />
                               </p>
                               <p> 
                                   <label for="emailsignup" class="youmail"  > Your email</label>
                                   <input id="emailsignup" name="email_address" required="required" type="email" placeholder="mysupermail@mail.com"/> 
                               </p>
                               <p> 
                                   <label for="passwordsignup" class="youpasswd" >Your password </label>
                                   <input id="passwordsignup" name="password" required="required" type="password" placeholder="eg. X8df!90EO"/>
                               </p>
                               <p> 
                                   <label for="passwordsignup_confirm" class="youpasswd" >Please confirm your password </label>
                                   <input id="passwordsignup_confirm" name="password_confirmation" required="required" type="password" placeholder="eg. X8df!90EO"/>
                               </p>
                               <p class="signin button"> 
                                   <input type="submit" value="Sign up"/> 
                               </p>
                               <p class="change_link">  
                                   Already a member ?
                                   <a class="singup_btn" href="#tologin" class="to_register"> Go and log in </a>
                               </p>
                           </form>
                           <div >
                           </div>
                       </div>


                         <div id="otp" class="animate form" style="padding-top: 55px;padding-bottom: 144px;">
                            
                               <h1>Log as Guest</h1> 
                            <!-- <form class="form-signin" action="<?php echo site_url(); ?>user/send_otp" method="post"> -->

                                    <samp id="send_otp_div"> 
                                        <div style="display:none" class="text-align-center sending_top_icon" style="color:#000">
                                            <img style="height: 52px;" src="<?php echo site_url(); ?>/assets/images/loading.gif"> <br> Sending OTP 
                                        </div>
                                        <p style="margin-top: 32px;"> 
                                            <label for="mobile Number" class="uname" > Enter Your mobile </label>
                                            <input id="opt_mobile" autofocus name="mobile" required="required" type="text" placeholder="Mobile Number"/>
                                        </p>
                                        <p class="login button" style="margin-top: 25px;"> 
                                            <button class="btn btn-primary" id="send_otp"> send otp </button>
                                        </p>
                                    </samp> 
                            
                            <!-- </form> -->


                           
                            <samp  id ="enter_otp" style="display:none">
                         
                            <div class=" msg_class alert alert-sm alert-border-left  light alert-dismissable">
                                            <button type="button" class="close" data-dismiss="alert"
                                                    aria-hidden="true">×</button>
                                            <i class="fa fa-info pr10"></i> <strong id="msg"> Opt successully send  </strong>
                            </div>
                              
                              
                               <p style="margin-top: 32px;"> 
                                   <label for="mobile Number" class="uname" > Enter OTP </label>
                                   <input  autofocus id="opt_user" name="otp" required="required" type="text" placeholder="OTP"/>
                               </p>
                               
                               <p class="login button" style="margin-top: 25px;"> 
                                     <button class="btn btn-primary" id="verify_otp_btn"> Submit </button>
                               </p>



                                <p class="keeplogin">
                                   <label style="float:left; margin-top: -40px;;"><a style=" cursor:pointer; text-decoration:none;color: rgb(64, 92, 96);" id="resend_otp_btn">Resend OTP </a></label>
                               </p>

                               
                            </samp>



                            <p class="change_link" style="margin-top: 91px;padding: 10px 19px; height: 52px;">
                                Not a member yet ?
                                <a href="#toregister" class=" singup_btn to_register">Join us</a>
                            </p>
                           
                       </div>
					   <!--Forgot Password-->
					    <div id="forgot" class="animate form">
                            <form class="" action="<?php echo site_url(); ?>user/forgotpassword" method="post">
                               <h1>Forgot Password</h1> 
                               <p> 
                                   <label for="username" class="uname" > Your email</label>
                                   <input type="email" id="inputEmail" class="" placeholder="Email address" required autofocus name="email">
                               </p>
                               <!--<p class="keeplogin"> 
                                   
                                   <label style="float:right;margin-top: 5px; text-align:right;"><a style="text-decoration:none;color: rgb(64, 92, 96);" href="<?php echo site_url(); ?>user/login">Sign In.</a></label>
                               </p>-->
                               <p class="login button"> 
                                  <input type="submit" value="Submit">
                               </p>
							   <p class="change_link" style="margin-top: 91px;padding: 10px 19px; height: 52px;">
                                <a href="#tologin" class="singup_btn to_register">Sign In</a>
                            </p>
                           </form>
                       </div>
					   <!--Forgot password-->
                       
                   </div>
               </div>  
           </section>
           
       </div>

<?php $this->load->view('footer') ?>
<?php $this->load->view('js') ?>
<script src="<?php echo site_url();?>assets/plugins/jquery_validation/dist/jquery.validate.js"></script>
<script>
 $("#register_singup").validate({
    rules: {
        password:{
	        required: true,
            minlength: 6
		  },
          password_confirmation:{
	        required: true,
            equalTo: "#passwordsignup_confirm",
             minlength: 6
		  },
          email_address:{
            email: true,
            required: true,
        }, 	
      
        agent_mobile:{
	         required: true,
	         number:true,
	         minlength:9,
	         maxlength:10
		},		
	  },
          
		});

    </script>




<script>

$(document).ready(function() {
    if( $(location).attr('href') == "https://www.visitormantra.com/user/login#toregister"){
        $('#footer').css("margin-top","300px");
    }
     else {
        $('#footer').css("margin-top","0px");
    }
	
});


$(".singup_btn").click(function(){
    if( $(this).attr('href')== "#tologin"){
        $('#footer').css("margin-top","0px");
    }
     else if( $(this).attr('href')== "#tootp"){
        $('#footer').css("margin-top","0px");
    }
    else{
        $('#footer').css("margin-top","300px");
    }
});

$("#send_otp").click(function(){

$('.sending_top_icon').show();

 var mobile = $('#opt_mobile').val();
        $.ajax({
            type: "POST",
            url: "<?php echo site_url(); ?>user/send_otp",
            data: {mobile: mobile },
            dataType: "text",
            cache: false,
            success:
            function (data) {  
                console.log(data);
                $('#send_otp_div').hide();
                $('#enter_otp').show();
                $('.msg_class').addClass( "alert-success" );
            }
        });
});


$("#resend_otp_btn").click(function(){
 
 var mobile = $('#opt_mobile').val();

        $.ajax({
            type: "POST",
            url: "<?php echo site_url(); ?>user/resend_otp",
            data: {},
            dataType: "text",
            cache: false,
            success:
            function (data) {  
                console.log(data);
                $('#send_otp_div').hide();
                $('#enter_otp').show();
                $('.msg_class').addClass( "alert-success" );
                $('#msg').text('Otp has been sent !');
            }
        });
});


$("#verify_otp_btn").click(function(){
 
    var otp = $('#opt_user').val();
        $.ajax({
            type: "POST",
            url: "<?php echo site_url(); ?>user/verify_otp",
            data: { otp:otp },
            dataType: "text",
            cache: false,
            success:
            function (data) {  
                console.log(data);
                $('#send_otp_div').hide();
                $('#enter_otp').show();
                var obj = jQuery.parseJSON(data);
                // alert(obj.result);
                if(obj.result == "invalid Otp"){
                    $('.msg_class').addClass( "alert-danger");
                    $('#msg').text('you have Entered Invalid Otp !');
                }
                else{
                    window.location.href = "<?php echo site_url() ?>";
                }
            }
        });
});

</script>