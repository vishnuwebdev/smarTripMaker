<?php $this->load->view("header"); ?>

         
<section id="special" class="p-xs-8">
		<div class="container-fluid">
	<div class="row">
            <?php $this->load->view("customersidebar"); ?>

		
		<div class="col-md-9">
		    <div class="card">
		        <div class="card-body" style="background: white;">
                        <div class="row">
                            <div class="col-md-12">
                                <h4>My Bookings</h4>
                                <hr>
                            </div>
                        </div>
		            <div class="row">
		                <div class="col-md-12">
                        <?php
				if ($this->session->flashdata ( 'alert' ) !== NULl) {
					$bhanu_message = $this->session->flashdata ( 'alert' );
					?>
																													<div
			class="alert alert-sm alert-border-left <?php echo $bhanu_message['class'];?> light alert-dismissable">
                <button type="button" class="close" data-dismiss="alert"
                    aria-hidden="true">×</button>
                <i class="fa fa-info pr10"></i> <strong> <?php echo $bhanu_message['message'];?></strong>
            </div>
                
			<?php }?>



                        <table class="table table-striped custab table-bordered">
                            <thead>
                                <tr>
                                    <th>Sr</th>
                                    <th>Bid</th>
                                    <th>Pass Detail</th>
                                    <th>Fare Amount</th>
                                    <th>departure airport </th>
                                    <th>departure airport </th>
                                    <th class="text-center">Action</th>
                                </tr>
                            </thead>
                            <?php
                           
                            if(count($FBookingList) > 0){
                            foreach ($FBookingList as $key =>$Listing){ ?>
                                    <tr>
                                        <td><?php echo $key+1 ?></td>
                                        <td><?php echo $Listing['booklist']->fbook_id; ?></td>
                                        <td><?php foreach ($Listing["paxlist"] as $paxlist){  ?>
                                            <b> <?php echo $paxlist->fpax_title.'. '.$paxlist->fpax_first_name.' '.$paxlist->fpax_last_name; ?><br> </b>
                                            
                                            
                                        <?php   } ?></td>
                                        <td>Rs. <?php echo $Listing['booklist']->fbook_customer_fare; ?></td>
                                        <td><?php echo $Listing['booklist']->fbook_depart_airport.','.$Listing['booklist']->fbook_depart_city.','.$Listing['booklist']->fbook_depart_airport_code; ?></td>
                                        <td><?php echo $Listing['booklist']->fbook_arrive_airport.' ('.$Listing['booklist']->fbook_arrive_city.'),'.$Listing['booklist']->fbook_arrive_airport_code; ?></td>
                                        <td class="text-center">
										<?php if($Listing['booklist']->fbook_ob_booking_status=="Success"){?>
										<a style="margin: 5px;" class='btn btn-info btn-md' href="<?php echo site_url(); ?>user/print_ticket?ref_id=<?php echo bp_hash($Listing['booklist']->fbook_id); ?>"><span class="fa fa-printer"></span> Print Ticket</a> 
                                        <a style="margin: 5px;" href="<?php echo site_url(); ?>flight/cancel_request?ref_id=<?php echo url_encode($Listing['booklist']->fbook_id); ?>" class="btn btn-warning btn-md">Cancel Flight</a>
										 <?php } else {?>
											<p> Booking not completed </p>
										  <?php } ?>
                                        </td>
                                    </tr>
                            <?php } } else{ ?>
                                    
                                <tr>
                                    <td colspan="7">not found any records.</td>   
                            <?php } ?>
                            </table>
		                </div>
		            </div>
		            
		        </div>
		    </div>
		</div>
	</div>
</div>

<?php $this->load->view("footer"); ?>
<?php $this->load->view("js"); ?>